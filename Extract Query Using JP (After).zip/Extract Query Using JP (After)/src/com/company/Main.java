package com.company;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

class Info1{
    ArrayList<String> obj = new ArrayList<>();
    String stmt;
}

class Info2{
    String str, query;
}

public class Main {

    static List<Info1> infoSet1=new ArrayList<>();
    static List<Info2> infoSet2=new ArrayList<>();
    static ExtractQuery eq = new ExtractQuery();

    public static void FindExecute(File file){
        //System.out.println("fff"+file.getName());
        try {
            new VoidVisitorAdapter<Object>() {
                @Override
                public void visit(MethodCallExpr n, Object arg) {
                    super.visit(n, arg);
                    //System.out.println(n.getNameAsString());
                    if(n.getArguments().isEmpty() && (n.getNameAsString().equals("executeUpdate")
                            || n.getNameAsString().equals("executeQuery") || n.getNameAsString().equals("execute"))) {
                        //System.out.println("**" + n.getNameAsString());
                        Info1 info = new Info1();

                        info.stmt = n.getChildNodes().get(0).toString();

                        infoSet1.add(info);
                    }
                }
            }.visit(JavaParser.parse(file), null);
            // System.out.println(); // empty line
        } catch (RuntimeException e) {
            new RuntimeException(e);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void FindPrepStmt(File file){
        //System.out.println("fff"+file.getName());
        try {
            new VoidVisitorAdapter<Object>() {
                @Override
                public void visit(MethodCallExpr n, Object arg) {
                    super.visit(n, arg);
                    //System.out.println(n.getNameAsString());
                    if(n.getArguments().isNonEmpty() && (n.getNameAsString().equals("prepareStatement"))) {
                        //System.out.println("**" + n.getNameAsString());
                        Info2 info = new Info2();

                        if(n.getArguments().get(0).getMetaModel().toString().equals("NameExpr")){
                            info.str = n.getArguments().get(0).toString();
                        }
                        else{
                            info.query = n.getArguments().get(0).toString();
                            info.str = "";
                        }

                        infoSet2.add(info);
                    }
                }
            }.visit(JavaParser.parse(file), null);
            // System.out.println(); // empty line
        } catch (RuntimeException e) {
            new RuntimeException(e);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void FindStmtStr(File file){
        List<Integer> list = new ArrayList<>();

        infoSet2.forEach(info -> {

            try {
                new VoidVisitorAdapter<Object>() {
                    @Override

                    public void visit(VariableDeclarator n, Object arg) {
                        super.visit(n, arg);
                        //if(n.getName().toString().equals(info.stmt))System.out.println(info.stmt);

                        if(n.getInitializer().isPresent() && n.getName().toString().equals(info.str)){
                            info.query = n.getInitializer().get().toString();
                        }
                    }
                }.visit(JavaParser.parse(file), null);
            } catch (RuntimeException e) {
                new RuntimeException(e);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                new VoidVisitorAdapter<Object>() {
                    @Override

                    public void visit(AssignExpr n, Object arg) {
                        super.visit(n, arg);

                        if (n.getTarget().toString().equals(info.str)) {
                            info.query = n.getValue().toString();
                        }
                    }
                }.visit(JavaParser.parse(file), null);
            } catch (RuntimeException e) {
                new RuntimeException(e);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }


            //System.out.println("QQQQQQQQQ "+info.query);
        });
    }

    public static void FindSetObj(File file) {
        List<Integer> list = new ArrayList<>();

        infoSet1.forEach(info -> {

            try {
                new VoidVisitorAdapter<Object>() {
                    @Override

                    public void visit(MethodCallExpr n, Object arg) {
                        super.visit(n, arg);
                        //if(n.getName().toString().equals(info.stmt))System.out.println(info.stmt);

                        if (n.getNameAsString().equals("setObject") || n.getNameAsString().equals("setInt")
                                || n.getNameAsString().equals("setString")) {
                            info.obj.add(n.getArguments().get(1).toString());
                        }
                    }
                }.visit(JavaParser.parse(file), null);
            } catch (RuntimeException e) {
                new RuntimeException(e);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        });
    }

    public static void Extractor(String basePath, String fileName) throws Exception {
        File file = new File(basePath+"\\"+fileName);
        if(file.isDirectory()) return;

        infoSet1.clear();
        infoSet2.clear();
        FindExecute(file);
        FindPrepStmt(file);
        FindStmtStr(file);
        FindSetObj(file);
        String[] ffName = fileName.split("[.]");
        int i = 1;
        for(Info2 info: infoSet2) {
            if(info.query == null) continue;
            try {
                File f = new File(basePath+"\\Temp\\"+ffName[0]);
                if(!f.exists()) f.mkdir();
                FileWriter myWriter = new FileWriter(basePath+"\\Temp\\"+ffName[0]+"\\String"+i+".txt");
                myWriter.write(info.query);
                myWriter.close();
                eq.Extract(info.query,basePath+"\\Temp\\"+ffName[0]+"\\Query"+i+".sql", basePath+"\\Temp\\"+ffName[0]+"\\Map"+i+".txt");
                System.out.println(info.query);
            } catch (IOException e) {
                e.printStackTrace();
            }
            i++;
        }

        i = 1;
        for(Info1 info: infoSet1) {
            if(info.obj.isEmpty()) continue;
            try {
                File f = new File(basePath+"\\Temp\\"+ffName[0]);
                if(!f.exists()) f.mkdir();
                FileWriter myWriter = new FileWriter(basePath+"\\Temp\\"+ffName[0]+"\\SetObj"+i+".txt");
                for(String s: info.obj)
                    myWriter.write(s+"\n");
                myWriter.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
            i++;
        }
    }

    public static void main(String[] args) throws Exception {
        String basePath = "C:\\Users\\shami\\Documents\\Undergrad-Thesis\\Getafix Code\\AST_DIFF\\After";

        File directoryPath = new File(basePath);
        String[] contents = directoryPath.list();

        for(int i = 0; i < contents.length; i++){  //contents.length
            System.out.println("******"+contents[i]);
            Extractor(basePath, contents[i]);
        }
    }
}
