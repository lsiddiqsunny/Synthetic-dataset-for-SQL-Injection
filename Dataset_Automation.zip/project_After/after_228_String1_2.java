public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM officeVisit WHERE patientMID=?");
		stmt.setObject(1 , patientID);
		stmt.executeQuery();
	}
}