public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "update Book set name = '?', idAuthor =?where id =?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , book.getName());
		stmt.setObject(2 , book.getIdAuthor());
		stmt.setObject(3 , book.getId());
		stmt.executeUpdate();
	}
}