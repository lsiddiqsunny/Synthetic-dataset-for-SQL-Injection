public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ParcClient WHERE codeTParc = ? AND codeCliPros = ?");
		stmt.setObject(1 , idType);
		stmt.setObject(2 , codeClient);
		stmt.executeQuery();
	}
}