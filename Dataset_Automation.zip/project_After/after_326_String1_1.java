public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE ActivityType SET " + "name= '?', " + "maxParticipants= '?' " + "WHERE id= '?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , activityTypeNewObj.getName());
		stmt.setObject(2 , activityTypeNewObj.getMaxParticipants());
		stmt.setObject(3 , activityTypeNewObj.getID());
		stmt.executeUpdate();
	}
}