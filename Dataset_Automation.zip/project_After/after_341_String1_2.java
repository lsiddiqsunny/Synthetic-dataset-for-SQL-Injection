public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT MAX(users.mid) FROM users WHERE mid BETWEEN ? AND ?");
		stmt.setObject(1 , minID);
		stmt.setObject(2 , maxID);
		stmt.executeQuery();
	}
}