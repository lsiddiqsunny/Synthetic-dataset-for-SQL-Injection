public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("insert into personas (NOMBRE,EDAD,PESO)" + "values (?,?,?)");
		stmt.setObject(1 , p.getNombre());
		stmt.setObject(2 , p.getEdad());
		stmt.setObject(3 , p.getPeso());
		stmt.executeUpdate();
	}
}