public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "select * from inception_music where musicUrl = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , url);
		stmt.executeQuery();
	}
}