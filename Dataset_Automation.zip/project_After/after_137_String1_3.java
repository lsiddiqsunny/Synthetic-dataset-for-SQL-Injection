public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "SELECT * FROM service_order " + "WHERE memberid = ? AND expiration_date IS null " + "ORDER BY need_by_date DESC";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}