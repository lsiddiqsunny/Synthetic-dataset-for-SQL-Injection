public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM Pays WHERE codePays = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , code);
		stmt.executeQuery();
	}
}