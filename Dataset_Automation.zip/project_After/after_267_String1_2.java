public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM T_HT_ATIVIDADE WHERE CD_ATIVIDADE = ?");
		stmt.setObject(1 , codigoBusca);
		stmt.executeQuery();
	}
}