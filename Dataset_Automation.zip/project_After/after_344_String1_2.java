public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM personnel WHERE MID=?");
		stmt.setObject(1 , pid);
		stmt.executeQuery();
	}
}