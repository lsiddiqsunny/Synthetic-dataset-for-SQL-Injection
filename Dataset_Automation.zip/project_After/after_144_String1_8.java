public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("UPDATE users " + "SET password = ?, change_user_name = javauser, change_date = ?" + "WHERE id = ?");
		stmt.setObject(1 , passwordBean.getPassword1());
		stmt.setObject(2 , GenericUtilities.getCurrentTimeStamp());
		stmt.setObject(3 , userId);
		stmt.executeUpdate();
	}
}