public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("INSERT INTO service_order " + "(memberid, service_group, service_type_mow, service_type_edge, service_type_rake, " + "instruction, need_by_date, create_user_name, create_date, change_user_name, change_date)" + "VALUES (?,?,?,?,?,?,?,?,?,?,?)");
		stmt.setObject(1 , serviceOrder.getId());
		stmt.setObject(2 , serviceOrder.getServiceGroup());
		stmt.setObject(3 , serviceOrder.getServiceTypeMow());
		stmt.setObject(4 , serviceOrder.getServiceTypeEdge());
		stmt.setObject(5 , serviceOrder.getServiceTypeRake());
		stmt.setObject(6 , serviceOrder.getInstruction());
		stmt.setObject(7 , new java.sql.Date(serviceOrder.getNeedByDate().getTime()));
		stmt.setObject(8 , "javauser");
		stmt.setObject(9 , GenericUtilities.getCurrentTimeStamp());
		stmt.setObject(10 , "javauser");
		stmt.setObject(11 , GenericUtilities.getCurrentTimeStamp());
		stmt.executeUpdate();
	}
}