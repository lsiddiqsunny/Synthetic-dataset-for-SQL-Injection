public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM OptionVisite WHERE type = ? and niveau = 0");
		stmt.setObject(1 , valeur);
		stmt.executeQuery();
	}
}