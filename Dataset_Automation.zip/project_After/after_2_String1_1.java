public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM COUNTRY WHERE COUNTRY_ID = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , country.getCountry_id());
		stmt.executeUpdate();
	}
}