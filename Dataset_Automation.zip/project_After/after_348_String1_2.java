public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) AS activityTypeInstances FROM ActivityType " + " WHERE id<> '?' AND name= '?'");
		stmt.setObject(1 , id);
		stmt.setObject(2 , name);
		stmt.executeQuery();
	}
}