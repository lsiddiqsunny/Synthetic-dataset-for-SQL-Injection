public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ParcClient WHERE id = ?");
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}