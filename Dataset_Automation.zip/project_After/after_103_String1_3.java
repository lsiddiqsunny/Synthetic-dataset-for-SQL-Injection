public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "SELECT * " + "FROM (SELECT id, pwd, name, phone, email, address, memo, rating, rownum as num FROM member) " + "WHERE num >= ? AND num <= ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , start);
		stmt.setObject(2 , end);
		stmt.executeQuery();
	}
}