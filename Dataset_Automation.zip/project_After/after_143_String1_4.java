public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		sql = "UPDATE service_order " + "SET need_by_date = ?, service_type_mow = ?, service_type_edge = ?, " + "service_type_rake = ?, instruction = ?, change_user_name = javauser, change_date = ? " + "WHERE id = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , new java.sql.Date(serviceOrder.getNeedByDate().getTime()));
		stmt.setObject(2 , serviceOrder.getServiceTypeMow());
		stmt.setObject(3 , serviceOrder.getServiceTypeEdge());
		stmt.setObject(4 , serviceOrder.getServiceTypeRake());
		stmt.setObject(5 , serviceOrder.getInstruction());
		stmt.setObject(6 , GenericUtilities.getCurrentTimeStamp());
		stmt.setObject(7 , serviceOrder.getId());
		stmt.executeUpdate();
	}
}