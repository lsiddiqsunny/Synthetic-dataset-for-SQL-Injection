public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM OptionVisite WHERE label = ?");
		stmt.setObject(1 , label);
		stmt.executeQuery();
	}
}