public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "SELECT * FROM message WHERE to_id = ? ORDER BY sent_date DESC";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , mid);
		stmt.executeQuery();
	}
}