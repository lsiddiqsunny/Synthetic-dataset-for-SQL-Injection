public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM declaredhcp WHERE PatientID=? AND HCPID=?");
		stmt.setObject(1 , pid);
		stmt.setObject(2 , hcpid);
		stmt.executeQuery();
	}
}