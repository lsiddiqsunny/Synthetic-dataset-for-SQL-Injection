public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE from ADMIN where EMAIL LIKE ?;");
		stmt.setObject(1 , email);
		stmt.executeUpdate();
	}
}