public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE ndcodes SET Description = ? " + "WHERE Code = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , med.getDescription());
		stmt.setObject(2 , med.getNDCode());
		stmt.executeUpdate();
	}
}