public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT DISTINCT course.idcourse, courname, faculty FROM course, instrcourdoc " + "WHERE idinstructor = ? AND course.idcourse = instrcourdoc.idcourse ORDER BY courname");
		stmt.setObject(1 , instrId);
		stmt.executeQuery();
	}
}