public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "DELETE FROM bespeak WHERE order_num=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , order_num);
		stmt.executeUpdate();
	}
}