public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT COUNT(*) AS activityTypeInstances FROM ActivityType " + " WHERE id<> '?' AND name= '?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.setObject(2 , name);
		stmt.executeQuery();
	}
}