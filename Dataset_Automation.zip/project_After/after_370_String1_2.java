public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT into user(name, username, password) values('?'," + "'?','?')");
		stmt.setObject(1 , name);
		stmt.setObject(2 , uname);
		stmt.setObject(3 , pwd);
		stmt.executeUpdate();
	}
}