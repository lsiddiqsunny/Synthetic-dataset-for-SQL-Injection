public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("delete FROM book where id = ? and name= '?'");
		stmt.setObject(1 , book.getId());
		stmt.setObject(2 , book.getName());
		stmt.executeUpdate();
	}
}