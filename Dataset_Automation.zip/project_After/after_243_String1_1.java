public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO ActivityBooking(id, guestId, date, status) VALUES ('?','?','?','?')";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , nextActivityBookingId);
		stmt.setObject(2 , acticityBookingObj.getGuest().getId());
		stmt.setObject(3 , acticityBookingObj.getDate());
		stmt.setObject(4 , acticityBookingObj.getStatus());
		stmt.executeUpdate();
	}
}