public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("delete from mensagem where id = '?'");
		stmt.setObject(1 , id);
		stmt.executeUpdate();
	}
}