public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO Resurse_Financiare  VALUES(?,?,?)");
		stmt.setObject(1 , rf.getDescriere());
		stmt.setObject(2 , rf.getSuma());
		stmt.setObject(3 , tip);
		stmt.executeUpdate();
	}
}