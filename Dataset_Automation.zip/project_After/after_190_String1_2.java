public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("delete from TB_DATE where d_year_4 = ?");
		stmt.setObject(1 , dYear4);
		stmt.executeUpdate();
	}
}