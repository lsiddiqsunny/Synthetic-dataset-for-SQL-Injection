public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM T_HT_ATIVIDADE WHERE CD_ATIVIDADE = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , cd_atividade);
		stmt.executeUpdate();
	}
}