public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "insert into mensagem(de, para, mensagem) values(?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , msg.getDeEmail());
		stmt.setObject(2 , msg.getParaEmail());
		stmt.setObject(3 , msg.getMensagem());
		stmt.executeUpdate();
	}
}