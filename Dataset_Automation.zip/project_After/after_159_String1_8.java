public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("insert into inception_music " + "( musicName, musicStyle," + " musicLanguage, artistName, albumName, " + "musicUrl, imageUrl, lyrics, " + "publishDate, description, " + "uploadedBy, uploadDate, fileLength, musicLength) " + "values (? , ? , ? , ? , ?, ?, ?, ? , ? , ?, ?, ?, ?, ?)");
		stmt.setObject(1 , m.getMusicName());
		stmt.setObject(2 , m.getMusicStyle());
		stmt.setObject(3 , m.getMusicLanguage());
		stmt.setObject(4 , m.getArtistName());
		stmt.setObject(5 , m.getAlbumName());
		stmt.setObject(6 , m.getMusicUrl());
		stmt.setObject(7 , m.getImageUrl());
		stmt.setObject(8 , m.getLyrics());
		stmt.setObject(9 , m.getPublishDate());
		stmt.setObject(10 , m.getDescription());
		stmt.setObject(11 , m.getUploadedBy());
		stmt.setObject(12 , DateUtil.getDateTime());
		stmt.setObject(13 , m.getFileLength());
		stmt.setObject(14 , m.getMusicLength());
		stmt.executeUpdate();
	}
}