public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("Select * from User where userName=? ");
		stmt.setObject(1 , userName);
		stmt.executeQuery();
	}
}