public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM virtual_machine_host_table WHERE hostname='?'");
		stmt.setObject(1 , hostname);
		stmt.executeQuery();
	}
}