public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "SELECT title FROM book WHERE no = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , b.getNo());
		stmt.executeQuery();
	}
}