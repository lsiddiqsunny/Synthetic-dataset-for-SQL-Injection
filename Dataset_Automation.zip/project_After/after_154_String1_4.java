public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		sql = "INSERT INTO `movie_feature`(`movie_id`, `pic`) VALUES (?,?)";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , movie_id);
		stmt.setObject(2 , pic);
		stmt.executeUpdate();
	}
}