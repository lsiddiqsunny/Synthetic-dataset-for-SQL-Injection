public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO " + tableLabel + " (fldAchievementTitle,fldProgress,fldBronzeGoal,fldSilverGoal,fldGoldGoal,fldStatus) VALUES(?,?,?,?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , fldAchievementTitle);
		stmt.setObject(2 , fldProgress);
		stmt.setObject(3 , fldBronzeGoal);
		stmt.setObject(4 , fldSilverGoal);
		stmt.setObject(5 , fldGoldGoal);
		stmt.setObject(6 , fldStatus);
		stmt.executeUpdate();
	}
}