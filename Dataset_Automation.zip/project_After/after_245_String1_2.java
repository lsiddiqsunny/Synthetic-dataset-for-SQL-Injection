public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM `order_movie` where order_id = ?");
		stmt.setObject(1 , order_id);
		stmt.executeQuery();
	}
}