public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "UPDATE member SET memo=?, rating=? WHERE id=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , memos[i]);
		stmt.setObject(2 , Integer.parseInt(ratings[i]));
		stmt.setObject(3 , ids[i]);
		stmt.executeUpdate();
	}
}