public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO personnel(MID, Role) VALUES(?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , Long.valueOf(nextID).toString());
		stmt.setObject(2 , role.name());
		stmt.executeUpdate();
	}
}