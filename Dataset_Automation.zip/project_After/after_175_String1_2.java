public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT id,idAuthor FROM book where name='?'");
		stmt.setObject(1 , bookName);
		stmt.executeQuery();
	}
}