public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM member WHERE account=? AND passwd=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , account);
		stmt.setObject(2 , passwd);
		stmt.executeQuery();
	}
}