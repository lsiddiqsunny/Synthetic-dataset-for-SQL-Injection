public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("DELETE FROM ingresso WHERE id=?");
		stmt.setObject(1 , id);
		stmt.executeUpdate();
	}
}