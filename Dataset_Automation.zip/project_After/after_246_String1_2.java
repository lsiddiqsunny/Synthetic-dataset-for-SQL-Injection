public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM ActivityBooking WHERE id= '?'");
		stmt.setObject(1 , id);
		stmt.executeUpdate();
	}
}