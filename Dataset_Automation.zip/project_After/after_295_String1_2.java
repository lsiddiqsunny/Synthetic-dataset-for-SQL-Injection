public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO representatives(RepresenterMID,RepresenteeMID) VALUES (?,?)");
		stmt.setObject(1 , representer);
		stmt.setObject(2 , representee);
		stmt.executeUpdate();
	}
}