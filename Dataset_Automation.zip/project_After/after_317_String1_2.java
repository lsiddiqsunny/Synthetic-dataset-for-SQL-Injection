public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO ActivityType(id, name, maxParticipants) VALUES ('?','?','?')");
		stmt.setObject(1 , nextActivityTypeId);
		stmt.setObject(2 , activityTypeObj.getName());
		stmt.setObject(3 , activityTypeObj.getMaxParticipants());
		stmt.executeUpdate();
	}
}