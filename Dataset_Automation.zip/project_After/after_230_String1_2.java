public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT DateOfBirth FROM patients WHERE MID=?");
		stmt.setObject(1 , patientMID);
		stmt.executeQuery();
	}
}