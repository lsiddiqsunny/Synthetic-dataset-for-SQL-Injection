public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("UPDATE member SET memo=?, rating=? WHERE id=?");
		stmt.setObject(1 , memos[i]);
		stmt.setObject(2 , Integer.parseInt(ratings[i]));
		stmt.setObject(3 , ids[i]);
		stmt.executeUpdate();
	}
}