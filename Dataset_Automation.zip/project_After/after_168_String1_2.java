public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update inception_music set lyrics = ? where id = ?");
		stmt.setObject(1 , lrc);
		stmt.setObject(2 , id);
		stmt.executeUpdate();
	}
}