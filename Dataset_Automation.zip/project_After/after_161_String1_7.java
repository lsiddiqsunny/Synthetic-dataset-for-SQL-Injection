public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "update inception_music set CTR = CTR + 1 where musicUrl = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , musicUrl);
		stmt.executeUpdate();
	}
}