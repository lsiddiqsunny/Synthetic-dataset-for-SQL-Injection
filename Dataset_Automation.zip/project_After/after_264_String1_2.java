public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO T_HT_ATIVIDADE (CD_ATIVIDADE, DT_ATIVIDADE, DS_ATIVIDADE, CD_USUARIO) VALUES (SQ_T_HT_ATIVIDADE.NEXTVAL, ?, ?, ?)");
		stmt.setObject(1 , data);
		stmt.setObject(2 , atividadesFisicas.getDs_atividade());
		stmt.setObject(3 , atividadesFisicas.getCd_usuario());
		stmt.executeUpdate();
	}
}