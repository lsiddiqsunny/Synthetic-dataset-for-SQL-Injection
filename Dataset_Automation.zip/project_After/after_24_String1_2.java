public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ADMIN WHERE EMAIL LIKE ?;");
		stmt.setObject(1 , username);
		stmt.executeQuery();
	}
}