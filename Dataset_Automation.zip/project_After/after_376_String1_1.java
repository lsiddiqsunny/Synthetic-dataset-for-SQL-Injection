public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT OR REPLACE INTO ClassifiedCompetences (CompetenceText, Quality, Importance, Type, AdID) VALUES(?,?,?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , competence.getCompetence());
		stmt.setObject(2 , competence.getQuality());
		stmt.setObject(3 , competence.getImportance());
		stmt.setObject(4 , competence.getType().toString());
		stmt.setObject(5 , competence.getJobAdID());
		stmt.executeUpdate();
	}
}