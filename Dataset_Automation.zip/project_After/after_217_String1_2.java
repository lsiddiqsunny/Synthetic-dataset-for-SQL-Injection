public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("insert into ? (?,?,?,?,?,?) " + "values(?,?,?,?,?,?)");
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_CODICE);
		stmt.setObject(3 , FIELD_COORD_X);
		stmt.setObject(4 , FIELD_COORD_Y);
		stmt.setObject(5 , FIELD_WIDTH);
		stmt.setObject(6 , FIELD_ID_MAPPA);
		stmt.setObject(7 , FIELD_ID_PIANO);
		stmt.setObject(8 , nodo.getCodice());
		stmt.setObject(9 , nodo.getCoord_X());
		stmt.setObject(10 , nodo.getCoord_Y());
		stmt.setObject(11 , nodo.getLarghezza());
		stmt.setObject(12 , nodo.getID_mappa());
		stmt.setObject(13 , nodo.getID_piano());
		stmt.executeUpdate();
	}
}