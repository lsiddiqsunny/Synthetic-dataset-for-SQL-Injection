public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "update inception_music set imageUrl = ? where id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , m.getImageUrl());
		stmt.setObject(2 , m.getId());
		stmt.executeUpdate();
	}
}