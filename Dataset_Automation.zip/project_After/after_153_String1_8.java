public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("select * from movie_feature where movie_id = ?");
		stmt.setObject(1 , movie_id);
		stmt.executeQuery();
	}
}