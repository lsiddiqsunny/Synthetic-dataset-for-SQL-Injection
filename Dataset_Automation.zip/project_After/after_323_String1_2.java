public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT nombre FROM tbl_peliculas WHERE nombre = ?");
		stmt.setObject(1 , entidad.getNombre());
		stmt.executeQuery();
	}
}