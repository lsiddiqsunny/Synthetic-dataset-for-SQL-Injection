public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "insert into " + table + "(docno,productname,reviewtitle,reviewcontent,pros,cons,reviewlink,reviewstar,reviewstarword) values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , docno);
		stmt.setObject(2 , pname);
		stmt.setObject(3 , revtitle);
		stmt.setObject(4 , revcontent);
		stmt.setObject(5 , pros);
		stmt.setObject(6 , cons);
		stmt.setObject(7 , rlink);
		stmt.setObject(8 , revstar);
		stmt.setObject(9 , starword);
		stmt.executeUpdate();
	}
}