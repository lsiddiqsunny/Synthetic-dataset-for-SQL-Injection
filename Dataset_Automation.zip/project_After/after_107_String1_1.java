public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM bespeak WHERE order_num=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , order_num);
		stmt.executeUpdate();
	}
}