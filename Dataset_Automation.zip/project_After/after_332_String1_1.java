public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select id,nombre,edad,peso from personas where id =?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}