public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT title,docfile FROM document WHERE iddocument = ?");
		stmt.setObject(1 , selFile.getDocid());
		stmt.executeQuery();
	}
}