public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update Book set name = '?', idAuthor =?where id =?");
		stmt.setObject(1 , book.getName());
		stmt.setObject(2 , book.getIdAuthor());
		stmt.setObject(3 , book.getId());
		stmt.executeUpdate();
	}
}