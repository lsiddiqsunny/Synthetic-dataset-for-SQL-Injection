public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM `movie_feature` where movie_id = ?");
		stmt.setObject(1 , movie_id);
		stmt.executeUpdate();
	}
}