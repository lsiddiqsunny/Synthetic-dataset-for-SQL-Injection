public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) AS activityLineNumbers FROM ActivityLine " + " WHERE bookingId='?' AND date= '?' AND status<>'Canceled' ");
		stmt.setObject(1 , bookingId);
		stmt.setObject(2 , data);
		stmt.executeQuery();
	}
}