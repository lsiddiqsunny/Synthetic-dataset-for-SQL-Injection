public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO " + table + " VALUES('', ? , ? " + ")");
		stmt.setObject(1 , desc);
		stmt.executeUpdate();
	}
}