public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select id,nombre,edad,peso from personas where id =?");
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}