public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		String sql = "select * from inception_music where albumName = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , album);
		stmt.executeQuery();
	}
}