public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO ndcodes (Code, Description) " + "VALUES (?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , med.getNDCode());
		stmt.setObject(2 , med.getDescription());
		stmt.executeUpdate();
	}
}