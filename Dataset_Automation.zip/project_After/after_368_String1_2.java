public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE MID=? AND isDependent=1");
		stmt.setObject(1 , mid);
		stmt.executeQuery();
	}
}