public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "SELECT COURSEID ,COURSENAME,UUIDS,ROOMID,COURSERDATE FROM course WHERE TEACHER=? AND (ROOMID IS NOT NULL AND ROOMID<>'') ";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , teachername);
		stmt.executeQuery();
	}
}