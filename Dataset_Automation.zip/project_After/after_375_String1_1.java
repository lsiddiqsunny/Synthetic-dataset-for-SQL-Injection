public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select * from ? where ? = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_QUOTA);
		stmt.setObject(3 , quota);
		stmt.executeQuery();
	}
}