public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM OptionVisite WHERE id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getId());
		stmt.executeUpdate();
	}
}