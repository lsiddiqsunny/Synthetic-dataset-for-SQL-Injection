public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO template_table VALUES(" + "'?'," + "'?'," + "'?')");
		stmt.setObject(1 , template.getName());
		stmt.setObject(2 , template.getPath());
		stmt.setObject(3 , template.getMd5());
		stmt.executeUpdate();
	}
}