public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "SELECT * FROM ingresso WHERE id=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , codigo);
		stmt.executeQuery();
	}
}