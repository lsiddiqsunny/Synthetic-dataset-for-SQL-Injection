public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM template_table WHERE name='?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , name);
		stmt.executeQuery();
	}
}