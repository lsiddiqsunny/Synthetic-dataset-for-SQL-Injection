public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "insert into " + TBL_NAME + " (" + FIELD_DATA + "," + FIELD_TIPO + "," + FIELD_TBL + ") values(?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , new Timestamp(System.currentTimeMillis()));
		stmt.setObject(2 , modifica.getTipo());
		stmt.setObject(3 , modifica.getTabella());
		stmt.executeUpdate();
	}
}