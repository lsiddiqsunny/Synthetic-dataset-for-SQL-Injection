public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("Insert into ? (Username,Password) values(? , ?);");
		stmt.setObject(1 , dbTableName);
		stmt.setObject(2 , username);
		stmt.setObject(3 , password);
		stmt.executeUpdate();
	}
}