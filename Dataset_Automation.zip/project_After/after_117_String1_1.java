public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM ingresso WHERE id=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , codigo);
		stmt.executeQuery();
	}
}