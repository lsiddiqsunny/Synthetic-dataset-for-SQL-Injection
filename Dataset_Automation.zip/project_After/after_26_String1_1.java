public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE from ADMIN where EMAIL LIKE ?;";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , email);
		stmt.executeUpdate();
	}
}