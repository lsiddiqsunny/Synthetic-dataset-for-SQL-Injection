public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM representatives WHERE RepresenterMID=? AND RepresenteeMID=?");
		stmt.setObject(1 , representer);
		stmt.setObject(2 , representee);
		stmt.executeUpdate();
	}
}