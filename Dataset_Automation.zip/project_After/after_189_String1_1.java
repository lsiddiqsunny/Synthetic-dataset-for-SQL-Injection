public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO virtual_machine_host_table VALUES(" + "'?'," + "'?'," + "'?')";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , host.getHostName());
		stmt.setObject(2 , host.getIp());
		stmt.setObject(3 , host.getNaeglingPort());
		stmt.executeUpdate();
	}
}