public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM notes WHERE id_user = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , owner.getIdentifier());
		stmt.executeQuery();
	}
}