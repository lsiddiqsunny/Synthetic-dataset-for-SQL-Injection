public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("Select * FROM users WHERE MID=? AND password=?");
		stmt.setObject(1 , mid);
		stmt.setObject(2 , DigestUtils.sha256Hex(password + salt));
		stmt.executeQuery();
	}
}