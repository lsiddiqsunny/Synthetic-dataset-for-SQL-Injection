public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO loginfailures(IPAddress, failureCount) VALUES(?,?)");
		stmt.setObject(1 , ipAddr);
		stmt.setObject(2 , failureCount);
		stmt.executeUpdate();
	}
}