public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM ActivityBooking WHERE guestId= '?' AND date= '?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , guestId);
		stmt.setObject(2 , data);
		stmt.executeUpdate();
	}
}