public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT MAX(users.mid) FROM users WHERE mid BETWEEN ? AND ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , minID);
		stmt.setObject(2 , maxID);
		stmt.executeQuery();
	}
}