public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ndcodes WHERE Code = ?");
		stmt.setObject(1 , code);
		stmt.executeQuery();
	}
}