public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM notes WHERE id_user = ?");
		stmt.setObject(1 , owner.getIdentifier());
		stmt.executeQuery();
	}
}