public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM OptionVisite WHERE parent = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}