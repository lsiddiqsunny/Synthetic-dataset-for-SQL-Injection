public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE resetpasswordfailures SET failurecount=failurecount+1 WHERE ipaddress=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , ipAddr);
		stmt.executeUpdate();
	}
}