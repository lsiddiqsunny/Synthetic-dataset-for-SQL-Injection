public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM ndcodes WHERE Code=?");
		stmt.setObject(1 , med.getNDCode());
		stmt.executeUpdate();
	}
}