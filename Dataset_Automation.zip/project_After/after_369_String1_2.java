public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT " + column + " FROM " + table + " WHERE id=?");
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}