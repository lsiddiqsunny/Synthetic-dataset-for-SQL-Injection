public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("SELECT COURSEID ,COURSENAME,UUIDS,ROOMID,COURSERDATE FROM course WHERE TEACHER=? AND (ROOMID IS NOT NULL AND ROOMID<>'') ");
		stmt.setObject(1 , teachername);
		stmt.executeQuery();
	}
}