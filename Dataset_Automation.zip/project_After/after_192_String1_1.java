public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO job_file_table VALUES(" + "'?'," + "'?'," + "'?'," + "?," + "?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , file.getName());
		stmt.setObject(2 , job.getName());
		stmt.setObject(3 , file.getAbsolutePath());
		stmt.setObject(4 , type);
		stmt.setObject(5 , status);
		stmt.executeUpdate();
	}
}