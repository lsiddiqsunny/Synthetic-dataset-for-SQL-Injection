public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "update ? set ? = last_insert_id(? + ?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , getIncrementerName());
		stmt.setObject(2 , columnName);
		stmt.setObject(3 , columnName);
		stmt.setObject(4 , getCacheSize());
		stmt.executeUpdate();
	}
}