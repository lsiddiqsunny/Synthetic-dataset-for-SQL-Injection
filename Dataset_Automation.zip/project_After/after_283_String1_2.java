public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM patients WHERE MID = ?");
		stmt.setObject(1 , mid);
		stmt.executeQuery();
	}
}