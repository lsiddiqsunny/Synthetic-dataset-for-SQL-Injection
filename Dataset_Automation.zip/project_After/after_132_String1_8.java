public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("INSERT INTO ModRgl (codeModRgl, nomModRgl) VALUES (?, ?)");
		stmt.setObject(1 , obj.getCodeModRgl());
		stmt.setObject(2 , obj.getNomModRgl());
		stmt.executeUpdate();
	}
}