public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Pays WHERE codePays = ?");
		stmt.setObject(1 , code);
		stmt.executeQuery();
	}
}