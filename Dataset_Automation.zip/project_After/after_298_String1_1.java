public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM representatives WHERE RepresenterMID=? AND RepresenteeMID=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , representer);
		stmt.setObject(2 , representee);
		stmt.executeUpdate();
	}
}