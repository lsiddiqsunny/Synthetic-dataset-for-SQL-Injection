public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO ParcClient (codeTParc, codeCliPros, quantite, date, nom) VALUES (?, ?, ?, ?, ?)");
		stmt.setObject(1 , obj.getCodeTParc());
		stmt.setObject(2 , obj.getCodeCliPros());
		stmt.setObject(3 , Integer.toString(obj.getQuantite()));
		stmt.setObject(4 , (obj.getDate() == null) ? "" : formatter.format(obj.getDate()));
		stmt.setObject(5 , obj.getNom());
		stmt.executeUpdate();
	}
}