public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE loginfailures SET FailureCount=FailureCount+1, lastFailure=CURRENT_TIMESTAMP WHERE IPAddress=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , ipAddr);
		stmt.executeUpdate();
	}
}