public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT firstName, lastName FROM personnel WHERE MID=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , mid);
		stmt.executeQuery();
	}
}