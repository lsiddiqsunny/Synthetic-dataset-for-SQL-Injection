public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO ndcodes (Code, Description) " + "VALUES (?,?)");
		stmt.setObject(1 , med.getNDCode());
		stmt.setObject(2 , med.getDescription());
		stmt.executeUpdate();
	}
}