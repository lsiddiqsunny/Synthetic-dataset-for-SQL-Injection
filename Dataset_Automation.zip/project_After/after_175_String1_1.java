public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT id,idAuthor FROM book where name='?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , bookName);
		stmt.executeQuery();
	}
}