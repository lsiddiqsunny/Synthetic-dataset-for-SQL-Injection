public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		sql = "SELECT * FROM message WHERE original_msg_id=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , refID);
		stmt.executeQuery();
	}
}