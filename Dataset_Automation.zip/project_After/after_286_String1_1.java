public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM declaredhcp, personnel " + "WHERE PatientID=? AND personnel.MID=declaredhcp.HCPID";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , pid);
		stmt.executeQuery();
	}
}