public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO adv_pendencia.tab_pedencia VALUES(null, ?,'Em aberto', ?, null, ?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , filtro.getDescPendencia());
		stmt.setObject(2 , filtro.getNomPendencia());
		stmt.setObject(3 , filtro.getPasta());
		stmt.setObject(4 , data);
		stmt.executeUpdate();
	}
}