public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM member WHERE id=?");
		stmt.setObject(1 , strId);
		stmt.executeUpdate();
	}
}