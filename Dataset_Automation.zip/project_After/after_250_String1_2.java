public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM ActivityBooking WHERE guestId= '?' AND date= '?'");
		stmt.setObject(1 , guestId);
		stmt.setObject(2 , data);
		stmt.executeUpdate();
	}
}