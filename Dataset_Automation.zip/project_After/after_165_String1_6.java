public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "update inception_music set musicName = ?, musicStyle = ?," + " musicLanguage = ?, artistName = ?, albumName = ? where id = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , music.getMusicName());
		stmt.setObject(2 , music.getMusicStyle());
		stmt.setObject(3 , music.getMusicLanguage());
		stmt.setObject(4 , music.getArtistName());
		stmt.setObject(5 , music.getAlbumName());
		stmt.setObject(6 , music.getId());
		stmt.executeUpdate();
	}
}