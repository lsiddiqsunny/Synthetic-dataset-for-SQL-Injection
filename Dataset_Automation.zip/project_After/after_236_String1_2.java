public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) AS nb FROM OptionVisite WHERE parent = ?");
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}