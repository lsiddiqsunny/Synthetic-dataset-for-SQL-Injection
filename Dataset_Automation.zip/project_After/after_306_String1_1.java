public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT COUNT(*) AS activityLineInstances3 FROM ActivityLine " + " WHERE bookingId= '?' " + "AND date= '?' " + "AND startHour= '?' " + "AND startHour= '?' " + "AND status<>'Canceled' ";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , bookingId);
		stmt.setObject(2 , date);
		stmt.setObject(3 , startHour);
		stmt.setObject(4 , startHour);
		stmt.executeQuery();
	}
}