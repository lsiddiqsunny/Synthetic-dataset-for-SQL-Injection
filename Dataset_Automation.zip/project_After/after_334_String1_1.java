public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE users SET sQuestion = ?, sAnswer = ? WHERE MID = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , question);
		stmt.setObject(2 , answer);
		stmt.setObject(3 , mid);
		stmt.executeUpdate();
	}
}