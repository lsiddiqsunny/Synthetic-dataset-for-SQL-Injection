public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update userinfo set pw=?, email=? where id=? and pw=?");
		stmt.setObject(1 , cpw);
		stmt.setObject(2 , email);
		stmt.setObject(3 , id);
		stmt.setObject(4 , pw);
		stmt.executeUpdate();
	}
}