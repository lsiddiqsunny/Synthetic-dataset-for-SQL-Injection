public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("SELECT * FROM ModRgl WHERE id = ?");
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}