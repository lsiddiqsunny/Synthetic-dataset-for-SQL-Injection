public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "Select Password from ? where Username = ?;";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , dbTableName);
		stmt.setObject(2 , username);
		stmt.executeQuery();
	}
}