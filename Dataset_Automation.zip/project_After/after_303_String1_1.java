public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT users.MID AS MID, users.Role AS Role, patients.firstName AS firstName, patients.lastName AS lastName FROM users INNER JOIN patients ON users.MID = patients.MID WHERE users.MID=?;";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , Long.toString(id));
		stmt.executeQuery();
	}
}