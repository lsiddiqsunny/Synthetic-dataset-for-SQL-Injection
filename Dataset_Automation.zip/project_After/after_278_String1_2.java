public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update adv_pendencia.tab_pasta set statusPasta = 'ocupado' where idPasta = ?");
		stmt.setObject(1 , filtro.getPasta());
		stmt.executeUpdate();
	}
}