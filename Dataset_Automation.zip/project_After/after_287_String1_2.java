public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO declaredhcp(PatientID, HCPID) VALUES(?,?)");
		stmt.setObject(1 , pid);
		stmt.setObject(2 , hcpID);
		stmt.executeUpdate();
	}
}