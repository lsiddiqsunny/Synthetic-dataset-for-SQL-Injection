public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO OrderList(bid,pid) " + "VALUES (?,?)");
		stmt.setObject(1 , orderlist.getBid());
		stmt.setObject(2 , orderlist.getPid());
		stmt.executeUpdate();
	}
}