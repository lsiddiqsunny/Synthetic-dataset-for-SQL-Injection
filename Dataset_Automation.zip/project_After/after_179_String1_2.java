public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("insert into Guitar(serialNumber,price,builder,type,backWood,topWood) values(?,?,?,?,?,?)");
		stmt.setObject(1 , guitar.getSerialNumber());
		stmt.setObject(2 , guitar.getPrice());
		stmt.setObject(3 , guitar.getSpec().getBuilder());
		stmt.setObject(4 , guitar.getSpec().getType());
		stmt.setObject(5 , guitar.getSpec().getBackWood());
		stmt.setObject(6 , guitar.getSpec().getTopWood());
		stmt.executeUpdate();
	}
}