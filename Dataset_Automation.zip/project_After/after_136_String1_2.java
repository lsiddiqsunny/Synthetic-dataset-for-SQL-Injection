public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ModRgl WHERE codeModRgl = ?");
		stmt.setObject(1 , code);
		stmt.executeQuery();
	}
}