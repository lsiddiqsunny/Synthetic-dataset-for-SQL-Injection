public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select name from login where name='?'");
		stmt.setObject(1 , name);
		stmt.setObject(2 , name);
		stmt.setObject(3 , password);
		stmt.executeQuery();
	}
}