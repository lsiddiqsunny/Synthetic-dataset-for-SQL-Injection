public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "DELETE FROM `movie_feature` where movie_id = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , movie_id);
		stmt.executeUpdate();
	}
}