public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select * from ? where ?=? AND ?=false order by ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_ID_MAPPA);
		stmt.setObject(3 , search_id);
		stmt.setObject(4 , FIELD_IS_PDI);
		stmt.setObject(5 , FIELD_CODICE);
		stmt.executeQuery();
	}
}