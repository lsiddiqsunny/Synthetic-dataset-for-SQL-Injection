public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "DELETE FROM ModRgl WHERE id = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getId());
		stmt.executeUpdate();
	}
}