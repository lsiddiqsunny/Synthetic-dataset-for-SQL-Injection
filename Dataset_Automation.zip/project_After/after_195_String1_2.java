public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM virtual_master_node_table WHERE domain='?'");
		stmt.setObject(1 , domain);
		stmt.executeQuery();
	}
}