public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT role FROM users WHERE MID=? AND Role=?");
		stmt.setObject(1 , mid);
		stmt.setObject(2 , role);
		stmt.executeQuery();
	}
}