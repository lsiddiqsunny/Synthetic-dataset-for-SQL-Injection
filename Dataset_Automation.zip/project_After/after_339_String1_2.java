public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM ActivityType WHERE name= '" + name + "'");
		stmt.setObject(1 , name);
		stmt.executeUpdate();
	}
}