public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "SELECT * FROM member WHERE account=? AND passwd=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , account);
		stmt.setObject(2 , passwd);
		stmt.executeQuery();
	}
}