public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE patients SET firstName=?,lastName=?,email=?," + "address1=?,address2=?,city=?,state=?,zip=?,phone=?," + "eName=?,ePhone=?,iCName=?,iCAddress1=?,iCAddress2=?,iCCity=?," + "ICState=?,iCZip=?,iCPhone=?,iCID=?,DateOfBirth=?," + "DateOfDeath=?,CauseOfDeath=?,MotherMID=?,FatherMID=?," + "BloodType=?,Ethnicity=?,Gender=?,TopicalNotes=?, CreditCardType=?, CreditCardNumber=?, " + "DirectionsToHome=?, Religion=?, Language=?, SpiritualPractices=?, " + "AlternateName=?, DateOfDeactivation=? WHERE MID=?");
		stmt.setObject(1 , p.getMID());
		stmt.executeUpdate();
	}
}