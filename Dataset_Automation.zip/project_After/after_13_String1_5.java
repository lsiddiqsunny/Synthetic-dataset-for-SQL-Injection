public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		String sql = "Select * from User where userName=? ";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , userName);
		stmt.executeQuery();
	}
}