public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select * from tablesr where dbname='?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , tableeasy.MainActivity.databases[tableeasy.MainActivity.selecteddata]);
		stmt.executeQuery();
	}
}