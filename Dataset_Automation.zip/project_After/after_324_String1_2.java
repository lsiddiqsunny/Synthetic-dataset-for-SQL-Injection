public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO gaurav_penalty( penalty_id , student_id , issue_date , recd_date ,  fineamount   ) VALUES ( ? ,?, ? , ?, ? ) ;");
		stmt.setObject(1 , fine.getPenalty_id());
		stmt.setObject(2 , fine.getstudent_id());
		stmt.setObject(3 , issuedate);
		stmt.setObject(4 , receivedate);
		stmt.setObject(5 , fine.getPenalty_amount());
		stmt.executeUpdate();
	}
}