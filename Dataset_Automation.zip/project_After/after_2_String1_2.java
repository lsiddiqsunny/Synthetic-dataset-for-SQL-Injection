public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM COUNTRY WHERE COUNTRY_ID = ?");
		stmt.setObject(1 , country.getCountry_id());
		stmt.executeUpdate();
	}
}