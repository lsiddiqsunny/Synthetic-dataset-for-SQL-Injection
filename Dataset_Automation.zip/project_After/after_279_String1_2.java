public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update adv_pendencia.tab_pasta set statusPasta = 'livre' where idPasta = ?");
		stmt.setObject(1 , pendencia.getIdPasta());
		stmt.executeUpdate();
	}
}