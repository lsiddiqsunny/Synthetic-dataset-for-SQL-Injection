public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select * from ? where ?=false " + "order by ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_IS_PDI);
		stmt.setObject(3 , FIELD_CODICE);
		stmt.executeQuery();
	}
}