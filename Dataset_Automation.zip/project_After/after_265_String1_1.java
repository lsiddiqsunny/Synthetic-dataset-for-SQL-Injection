public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE T_HT_ATIVIDADE SET CD_ATIVIDADE = ?, DS_ATIVIDADE = ?, CD_USUARIO = ? WHERE CD_ATIVIDADE = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , atividadesFisicas.getCd_atividade());
		stmt.setObject(2 , atividadesFisicas.getDs_atividade());
		stmt.setObject(3 , atividadesFisicas.getCd_usuario());
		stmt.setObject(4 , atividadesFisicas.getCd_usuario());
		stmt.executeUpdate();
	}
}