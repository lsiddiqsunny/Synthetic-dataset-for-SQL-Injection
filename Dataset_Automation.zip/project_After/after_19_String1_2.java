public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ? WHERE stock = ?;");
		stmt.setObject(1 , tableName);
		stmt.setObject(2 , stockIndex);
		stmt.executeQuery();
	}
}