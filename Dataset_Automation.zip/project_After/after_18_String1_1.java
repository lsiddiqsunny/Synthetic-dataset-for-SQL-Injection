public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE Resurse_Financiare  SET descriere=?, suma=?, tip=? where id=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , rf.getDescriere());
		stmt.setObject(2 , rf.getSuma());
		stmt.setObject(3 , tip);
		stmt.setObject(4 , rf.getId());
		stmt.executeUpdate();
	}
}