public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM virtual_master_node_table where domain='?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , domain);
		stmt.executeUpdate();
	}
}