public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "Select * FROM users WHERE MID=? AND password=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , mid);
		stmt.setObject(2 , DigestUtils.sha256Hex(password + salt));
		stmt.executeQuery();
	}
}