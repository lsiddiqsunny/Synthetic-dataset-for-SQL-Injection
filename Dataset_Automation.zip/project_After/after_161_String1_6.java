public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "update inception_music set CTR = CTR + 1 where musicUrl = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , musicUrl);
		stmt.executeUpdate();
	}
}