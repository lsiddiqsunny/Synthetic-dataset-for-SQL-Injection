public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO user(name,pass) VALUES(?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , name);
		stmt.setObject(2 , pass);
		stmt.executeUpdate();
	}
}