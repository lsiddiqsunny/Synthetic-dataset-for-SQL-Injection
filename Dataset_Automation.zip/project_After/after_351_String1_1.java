public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM personnel WHERE MID IN (SELECT UAP FROM hcprelations WHERE HCP=?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , hcpid);
		stmt.executeQuery();
	}
}