public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT mp.* FROM `movie_pic` mp JOIN movie m on m.movie_id = mp.movie_id WHERE m.movie_id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}