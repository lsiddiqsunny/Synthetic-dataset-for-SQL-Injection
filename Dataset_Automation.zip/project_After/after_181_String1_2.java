public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("delete from guitar where SerialNumber = ?");
		stmt.setObject(1 , SerialNumber);
		stmt.executeUpdate();
	}
}