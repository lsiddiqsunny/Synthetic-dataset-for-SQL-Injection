public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select * from inception_music where musicUrl = ?");
		stmt.setObject(1 , url);
		stmt.executeQuery();
	}
}