public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE OptionVisite SET label = ?, niveau = ?, parent = ?, type = ?, typeB = ? WHERE id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getLabel());
		stmt.setObject(2 , obj.getNiveau());
		stmt.setObject(3 , obj.getParent());
		stmt.setObject(4 , obj.getType());
		stmt.setObject(5 , obj.getTypeB());
		stmt.setObject(6 , obj.getId());
		stmt.executeUpdate();
	}
}