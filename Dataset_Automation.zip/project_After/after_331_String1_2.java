public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update personas set NOMBRE=?, EDAD=?, PESO=? where id=?");
		stmt.setObject(1 , p.getNombre());
		stmt.setObject(2 , p.getEdad());
		stmt.setObject(3 , p.getPeso());
		stmt.setObject(4 , p.getId());
		stmt.executeUpdate();
	}
}