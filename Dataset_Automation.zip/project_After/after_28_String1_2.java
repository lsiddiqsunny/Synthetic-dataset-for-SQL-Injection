public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO " + tableLabel + " (fldAchievementTitle,fldProgress,fldBronzeGoal,fldSilverGoal,fldGoldGoal,fldStatus) VALUES(?,?,?,?,?,?)");
		stmt.setObject(1 , fldAchievementTitle);
		stmt.setObject(2 , fldProgress);
		stmt.setObject(3 , fldBronzeGoal);
		stmt.setObject(4 , fldSilverGoal);
		stmt.setObject(5 , fldGoldGoal);
		stmt.setObject(6 , fldStatus);
		stmt.executeUpdate();
	}
}