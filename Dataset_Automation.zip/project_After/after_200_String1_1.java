public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM virtual_machine_host_table WHERE hostname='?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , hostname);
		stmt.executeQuery();
	}
}