public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select * from guitar where type= ? ");
		stmt.setObject(1 , type);
		stmt.executeQuery();
	}
}