public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM declaredhcp, personnel " + "WHERE PatientID=? AND personnel.MID=declaredhcp.HCPID");
		stmt.setObject(1 , pid);
		stmt.executeQuery();
	}
}