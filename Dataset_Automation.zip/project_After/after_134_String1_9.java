public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("UPDATE ModRgl SET codeModRgl = ?, nomModRgl = ? WHERE id = ?");
		stmt.setObject(1 , obj.getCodeModRgl());
		stmt.setObject(2 , obj.getNomModRgl());
		stmt.setObject(3 , obj.getId());
		stmt.executeUpdate();
	}
}