public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select * from inception_music where id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}