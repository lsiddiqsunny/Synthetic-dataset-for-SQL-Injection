public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("UPDATE ingresso SET local=?, datahora=?, lugar=?, quantidade=?, idcategoria=?, idtipoingresso=?, valor=? WHERE id=?");
		stmt.setObject(1 , adulto.getLocal());
		stmt.setObject(2 , new java.sql.Date(adulto.getDataHora().getTime()));
		stmt.setObject(3 , adulto.getLugar());
		stmt.setObject(4 , adulto.getQuantidade());
		stmt.setObject(5 , adulto.getCategoria().getId());
		stmt.setObject(6 , adulto.getTipoIngresso().getId());
		stmt.setObject(7 , adulto.getValor());
		stmt.setObject(8 , adulto.getId());
		stmt.executeUpdate();
	}
}