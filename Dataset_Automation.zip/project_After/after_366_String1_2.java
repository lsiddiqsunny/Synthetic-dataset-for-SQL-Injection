public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT smartreporter.field.Name, smartreporter.field.Size" + " FROM " + "smartreporter.field, smartreporter.template, smartreporter.user" + " WHERE " + "smartreporter.field.TemplateID=smartreporter.template.ID" + " AND " + "smartreporter.template.ACTIVE=1 " + " AND " + "smartreporter.template.User_ID=" + userID);
		stmt.setObject(1 , userID);
		stmt.executeQuery();
	}
}