public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select * from ? where ?=false " + "order by ?");
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_IS_PDI);
		stmt.setObject(3 , FIELD_CODICE);
		stmt.executeQuery();
	}
}