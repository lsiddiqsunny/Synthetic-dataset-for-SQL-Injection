public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT ITEM_NAME,QUANTITY,PRICE FROM HISTORY WHERE CUSTOMER_ID = ? ORDER BY ORDER_ID DESC");
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}