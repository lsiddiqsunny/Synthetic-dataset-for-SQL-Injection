public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO users (MID, PASSWORD, SALT, ROLE, sQuestion, sAnswer) VALUES (?,?,?,?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , mid);
		stmt.setObject(2 , hashedPassword);
		stmt.setObject(3 , salt);
		stmt.setObject(4 , role.toString());
		stmt.setObject(5 , "Enter the random password given in your account email");
		stmt.setObject(6 , password);
		stmt.executeUpdate();
	}
}