public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "UPDATE message SET been_read=1 WHERE message_id=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , mBean.getMessageId());
		stmt.executeUpdate();
	}
}