public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		sql = "UPDATE member SET memo=?, rating=? WHERE id=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , memo);
		stmt.setObject(2 , rating);
		stmt.setObject(3 , id);
		stmt.executeUpdate();
	}
}