public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("insert into " + TBL_NAME + " (" + FIELD_CODICE + "," + FIELD_IS_PDI + "," + FIELD_TIPO + "," + FIELD_COORD_X + "," + FIELD_COORD_Y + "," + FIELD_WIDTH + "," + FIELD_LENGTH + "," + FIELD_ID_MAPPA + "," + FIELD_ID_PIANO + ") values(?,?,?,?,?,?,?,?,?)");
		stmt.setObject(1 , pdi.getCodice());
		stmt.setObject(2 , pdi.getTipo());
		stmt.setObject(3 , pdi.getCoord_X());
		stmt.setObject(4 , pdi.getCoord_Y());
		stmt.setObject(5 , pdi.getLarghezza());
		stmt.setObject(6 , pdi.getLunghezza());
		stmt.setObject(7 , pdi.getID_mappa());
		stmt.setObject(8 , pdi.getID_piano());
		stmt.executeUpdate();
	}
}