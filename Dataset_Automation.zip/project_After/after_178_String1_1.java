public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * from shipping.ica_couriers where subo in (?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , suborder);
		stmt.executeQuery();
	}
}