public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO OrderList(bid,pid) " + "VALUES (?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , orderlist.getBid());
		stmt.setObject(2 , orderlist.getPid());
		stmt.executeUpdate();
	}
}