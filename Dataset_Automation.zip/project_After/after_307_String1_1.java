public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO Pays (codePays, nomPays) VALUES (?, ?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getCodePays());
		stmt.setObject(2 , obj.getNomPays());
		stmt.executeUpdate();
	}
}