public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "UPDATE service_order " + "SET expiration_date = ?, change_user_name = javauser, change_date = ?" + "WHERE id = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , new java.sql.Date(new java.util.Date().getTime()));
		stmt.setObject(2 , GenericUtilities.getCurrentTimeStamp());
		stmt.setObject(3 , serviceId);
		stmt.executeUpdate();
	}
}