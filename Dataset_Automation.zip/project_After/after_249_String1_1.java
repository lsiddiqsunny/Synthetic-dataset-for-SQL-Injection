public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "insert into atm_user" + "(id,userName,idCardNumber,gender,birthday,address,balance,account, password,type,state,remark)" + "value (?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , user.getId());
		stmt.setObject(2 , user.getUserName());
		stmt.setObject(3 , user.getIdCardNumber());
		stmt.setObject(4 , user.getGender());
		stmt.setObject(5 , date);
		stmt.setObject(6 , user.getAddress());
		stmt.setObject(7 , user.getBalance());
		stmt.setObject(8 , user.getAccount());
		stmt.setObject(9 , user.getPassword());
		stmt.setObject(10 , user.getType());
		stmt.setObject(11 , user.getState());
		stmt.setObject(12 , user.getRemark());
		stmt.executeUpdate();
	}
}