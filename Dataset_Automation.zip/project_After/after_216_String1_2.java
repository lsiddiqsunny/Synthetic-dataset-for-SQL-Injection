public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select * from ? where ?=? AND ?=true order by ?");
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_ID_MAPPA);
		stmt.setObject(3 , search_id);
		stmt.setObject(4 , FIELD_IS_PDI);
		stmt.setObject(5 , FIELD_CODICE);
		stmt.executeQuery();
	}
}