public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM T_HT_ATIVIDADE WHERE CD_ATIVIDADE = ?");
		stmt.setObject(1 , cd_atividade);
		stmt.executeUpdate();
	}
}