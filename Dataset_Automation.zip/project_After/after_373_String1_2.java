public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT Salt FROM users WHERE MID=?");
		stmt.setObject(1 , mid);
		stmt.executeQuery();
	}
}