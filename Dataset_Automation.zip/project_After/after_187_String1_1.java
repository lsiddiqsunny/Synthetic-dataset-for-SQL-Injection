public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO cluster_table VALUES(" + "'?')";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , cluster.getName());
		stmt.executeUpdate();
	}
}