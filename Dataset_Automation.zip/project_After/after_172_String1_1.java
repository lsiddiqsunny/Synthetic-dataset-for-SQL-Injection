public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "update member set islogin=0 where id=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , dbid);
		stmt.executeUpdate();
	}
}