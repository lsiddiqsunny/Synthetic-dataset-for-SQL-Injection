public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM message WHERE to_id = ? ORDER BY sent_date ASC";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , mid);
		stmt.executeQuery();
	}
}