public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM user WHERE Login = '?' AND Password=" + "'?'");
		stmt.setObject(1 , uname);
		stmt.setObject(2 , pwd);
		stmt.executeQuery();
	}
}