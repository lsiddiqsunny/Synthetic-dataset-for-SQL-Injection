public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO cluster_table VALUES(" + "'?')");
		stmt.setObject(1 , cluster.getName());
		stmt.executeUpdate();
	}
}