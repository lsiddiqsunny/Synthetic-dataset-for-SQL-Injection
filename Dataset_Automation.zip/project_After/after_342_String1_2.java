public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO personnel(MID, Role) VALUES(?,?)");
		stmt.setObject(1 , Long.valueOf(nextID).toString());
		stmt.setObject(2 , role.name());
		stmt.executeUpdate();
	}
}