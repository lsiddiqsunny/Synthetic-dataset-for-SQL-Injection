public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO ParcClient (codeTParc, codeCliPros, quantite, date, nom) VALUES (?, ?, ?, ?, ?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getCodeTParc());
		stmt.setObject(2 , obj.getCodeCliPros());
		stmt.setObject(3 , Integer.toString(obj.getQuantite()));
		stmt.setObject(4 , (obj.getDate() == null) ? "" : formatter.format(obj.getDate()));
		stmt.setObject(5 , obj.getNom());
		stmt.executeUpdate();
	}
}