public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE ParcClient SET codeTParc = ?, codeCliPros = ?, quantite = ?, date = ?, nom = ? WHERE id = ?");
		stmt.setObject(1 , obj.getCodeTParc());
		stmt.setObject(2 , obj.getCodeCliPros());
		stmt.setObject(3 , Integer.toString(obj.getQuantite()));
		stmt.setObject(4 , formatter.format(obj.getDate()));
		stmt.setObject(5 , obj.getNom());
		stmt.setObject(6 , obj.getId());
		stmt.executeUpdate();
	}
}