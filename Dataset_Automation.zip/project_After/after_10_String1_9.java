public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("Select * from User where userName=? and password=?");
		stmt.setObject(1 , login.getUserName());
		stmt.setObject(2 , login.getPassword());
		stmt.executeQuery();
	}
}