public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "insert into TB_DATE values ( ?, ?, ?, ?, ?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , record.getdYear4());
		stmt.setObject(2 , new java.sql.Date(record.getdDate().getTime()));
		stmt.setObject(3 , new java.sql.Timestamp(record.getdDatetime().getTime()));
		stmt.setObject(4 , new java.sql.Timestamp(record.getdTimestamp().getTime()));
		stmt.executeUpdate();
	}
}