public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO T_HT_ATIVIDADE (CD_ATIVIDADE, DT_ATIVIDADE, DS_ATIVIDADE, CD_USUARIO) VALUES (SQ_T_HT_ATIVIDADE.NEXTVAL, ?, ?, ?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , data);
		stmt.setObject(2 , atividadesFisicas.getDs_atividade());
		stmt.setObject(3 , atividadesFisicas.getCd_usuario());
		stmt.executeUpdate();
	}
}