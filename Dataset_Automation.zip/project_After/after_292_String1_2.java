public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT patients.* FROM representatives, patients, users " + "WHERE RepresenterMID=? AND RepresenteeMID=patients.MID AND users.MID=patients.MID AND users.isDependent=1");
		stmt.setObject(1 , pid);
		stmt.executeQuery();
	}
}