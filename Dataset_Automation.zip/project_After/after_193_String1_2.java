public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM virtual_slave_node_table WHERE cluster='?'");
		stmt.setObject(1 , cluster);
		stmt.executeQuery();
	}
}