public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT DISTINCT course.idcourse, courname, faculty FROM course, instrcourdoc " + "WHERE idinstructor = ? AND course.idcourse = instrcourdoc.idcourse ORDER BY courname";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , instrId);
		stmt.executeQuery();
	}
}