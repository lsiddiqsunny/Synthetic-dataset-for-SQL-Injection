public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT COURSENAME,TEACHER,ROOMID,COURSERDATE FROM course  WHERE COURSEID=?");
		stmt.setObject(1 , courseid);
		stmt.executeQuery();
	}
}