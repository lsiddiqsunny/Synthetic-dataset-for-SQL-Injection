public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO adv_pendencia.tab_pedencia VALUES(null, ?,'Em aberto', ?, null, ?,?)");
		stmt.setObject(1 , filtro.getDescPendencia());
		stmt.setObject(2 , filtro.getNomPendencia());
		stmt.setObject(3 , filtro.getPasta());
		stmt.setObject(4 , data);
		stmt.executeUpdate();
	}
}