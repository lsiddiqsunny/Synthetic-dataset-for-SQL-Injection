public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT COUNT(*) AS activityLineInstances2 FROM ActivityLine " + " WHERE date='?' AND startHour= '?' AND instructorId= '?'" + " AND status<>'Canceled' ";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , date);
		stmt.setObject(2 , startHour);
		stmt.setObject(3 , instructorId);
		stmt.executeQuery();
	}
}