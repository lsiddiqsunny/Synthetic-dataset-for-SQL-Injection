public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		sql = "SELECT * FROM `movie_feature` WHERE datepost < CURRENT_TIMESTAMP order by datepost desc LIMIT 0,?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , NoPage);
		stmt.executeQuery();
	}
}