public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM virtual_master_node_table where domain='?'");
		stmt.setObject(1 , domain);
		stmt.executeUpdate();
	}
}