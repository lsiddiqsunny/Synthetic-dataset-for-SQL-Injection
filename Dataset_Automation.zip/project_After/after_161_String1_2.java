public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update inception_music set CTR = CTR + 1 where musicUrl = ?");
		stmt.setObject(1 , musicUrl);
		stmt.executeUpdate();
	}
}