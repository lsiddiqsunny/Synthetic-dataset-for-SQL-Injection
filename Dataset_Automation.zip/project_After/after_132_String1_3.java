public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "INSERT INTO ModRgl (codeModRgl, nomModRgl) VALUES (?, ?)";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getCodeModRgl());
		stmt.setObject(2 , obj.getNomModRgl());
		stmt.executeUpdate();
	}
}