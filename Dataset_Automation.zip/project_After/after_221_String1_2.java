public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update ?  set ?=?, ?=?, ?=?, ?=?, ?=?, " + +"=? " + "where ?=?");
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_CODICE);
		stmt.setObject(3 , pdi.getCodice());
		stmt.setObject(4 , pdi.getTipo());
		stmt.setObject(5 , FIELD_COORD_X);
		stmt.setObject(6 , pdi.getCoord_Y());
		stmt.setObject(7 , FIELD_COORD_Y);
		stmt.setObject(8 , pdi.getLarghezza());
		stmt.setObject(9 , FIELD_WIDTH);
		stmt.setObject(10 , pdi.getLunghezza());
		stmt.setObject(11 , FIELD_LENGTH);
		stmt.setObject(12 , pdi.getLunghezza());
		stmt.setObject(13 , FIELD_ID);
		stmt.executeUpdate();
	}
}