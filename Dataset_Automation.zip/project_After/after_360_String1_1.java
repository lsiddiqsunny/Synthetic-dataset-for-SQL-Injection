public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select name from login where name='?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , name);
		stmt.setObject(2 , name);
		stmt.setObject(3 , password);
		stmt.executeQuery();
	}
}