public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM ingresso WHERE id=?");
		stmt.setObject(1 , codigo);
		stmt.executeQuery();
	}
}