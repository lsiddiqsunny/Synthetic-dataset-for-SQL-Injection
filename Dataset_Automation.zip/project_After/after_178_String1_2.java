public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * from shipping.ica_couriers where subo in (?)");
		stmt.setObject(1 , suborder);
		stmt.executeQuery();
	}
}