public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) AS activityBokingInstances FROM ActivityBooking " + " WHERE date='?' AND guestId='?' AND status<>'Canceled'");
		stmt.setObject(1 , data);
		stmt.setObject(2 , guestId);
		stmt.executeQuery();
	}
}