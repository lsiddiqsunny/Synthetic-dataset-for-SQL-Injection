public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM bespeak WHERE order_num=?");
		stmt.setObject(1 , order_num);
		stmt.executeUpdate();
	}
}