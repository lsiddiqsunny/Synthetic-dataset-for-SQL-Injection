public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update member set islogin=0 where id=?");
		stmt.setObject(1 , dbid);
		stmt.executeUpdate();
	}
}