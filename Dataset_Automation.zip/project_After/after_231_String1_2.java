public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO OptionVisite (id, label, niveau, parent, type, typeB) VALUES (?, ?, ?, ?, ?, ?)");
		stmt.setObject(1 , obj.getId());
		stmt.setObject(2 , obj.getLabel());
		stmt.setObject(3 , obj.getNiveau());
		stmt.setObject(4 , obj.getParent());
		stmt.setObject(5 , obj.getType());
		stmt.setObject(6 , obj.getTypeB());
		stmt.executeUpdate();
	}
}