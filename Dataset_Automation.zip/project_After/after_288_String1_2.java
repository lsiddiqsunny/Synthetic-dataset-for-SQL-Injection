public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) AS activityLineInstances2 FROM ActivityLine " + " WHERE date='?' AND startHour= '?' AND instructorId= '?'" + " AND status<>'Canceled' ");
		stmt.setObject(1 , date);
		stmt.setObject(2 , startHour);
		stmt.setObject(3 , instructorId);
		stmt.executeQuery();
	}
}