public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("Select Password from ? where Username = ?;");
		stmt.setObject(1 , dbTableName);
		stmt.setObject(2 , username);
		stmt.executeQuery();
	}
}