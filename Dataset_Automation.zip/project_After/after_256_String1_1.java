public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT COUNT(*) AS activityBokingInstances FROM ActivityBooking " + " WHERE date='?' AND guestId='?' AND status<>'Canceled'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , data);
		stmt.setObject(2 , guestId);
		stmt.executeQuery();
	}
}