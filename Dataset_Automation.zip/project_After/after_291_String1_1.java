public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT patients.* FROM representatives, patients " + "WHERE RepresenterMID=? AND RepresenteeMID=patients.MID";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , pid);
		stmt.executeQuery();
	}
}