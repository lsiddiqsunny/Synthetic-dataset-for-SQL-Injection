public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("select * from " + TBL_NAME + " where " + FIELD_DATA + " >= ? ");
		stmt.setObject(1 , data);
		stmt.executeQuery();
	}
}