public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("Update npc set npc_name = ?,npc_lvl = ?, " + "currency = ?, job_id = ? WHERE npc_id=?");
		stmt.setObject(1 , npc.getName());
		stmt.setObject(2 , npc.getLvl());
		stmt.setObject(3 , npc.getCurrency());
		stmt.setObject(4 , npc.getJobClass());
		stmt.setObject(5 , npc.getId());
		stmt.executeUpdate();
	}
}