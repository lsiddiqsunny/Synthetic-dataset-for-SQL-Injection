public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("update inception_music set CTR = CTR + 1 where id = ?");
		stmt.setObject(1 , id);
		stmt.executeUpdate();
	}
}