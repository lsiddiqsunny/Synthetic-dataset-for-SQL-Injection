public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE tblAchievements SET fldStatus=? WHERE id=?;";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , editAchievementStatus);
		stmt.setObject(2 , editIDResult);
		stmt.executeUpdate();
	}
}