public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "select * from guitar where type= ? ";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , type);
		stmt.executeQuery();
	}
}