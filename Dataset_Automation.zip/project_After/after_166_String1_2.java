public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("update inception_music set imageUrl = ? where id = ?");
		stmt.setObject(1 , m.getImageUrl());
		stmt.setObject(2 , m.getId());
		stmt.executeUpdate();
	}
}