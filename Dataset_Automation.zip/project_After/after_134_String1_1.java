public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE ModRgl SET codeModRgl = ?, nomModRgl = ? WHERE id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getCodeModRgl());
		stmt.setObject(2 , obj.getNomModRgl());
		stmt.setObject(3 , obj.getId());
		stmt.executeUpdate();
	}
}