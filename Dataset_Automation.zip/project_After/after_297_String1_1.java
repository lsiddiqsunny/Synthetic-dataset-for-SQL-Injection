public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM patients WHERE MID=? AND DateOfDeactivation IS NULL";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , pid);
		stmt.executeQuery();
	}
}