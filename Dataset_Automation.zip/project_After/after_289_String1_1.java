public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM declaredhcp WHERE PatientID=? AND HCPID=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , pid);
		stmt.setObject(2 , hcpID);
		stmt.executeUpdate();
	}
}