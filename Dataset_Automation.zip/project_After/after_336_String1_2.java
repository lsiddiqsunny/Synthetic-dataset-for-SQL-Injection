public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT DateOfDeactivation FROM patients WHERE MID=?");
		stmt.setObject(1 , mid);
		stmt.executeQuery();
	}
}