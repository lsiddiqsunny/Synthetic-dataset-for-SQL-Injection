public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select * from tablesr where dbname='?'");
		stmt.setObject(1 , tableeasy.MainActivity.databases[tableeasy.MainActivity.selecteddata]);
		stmt.executeQuery();
	}
}