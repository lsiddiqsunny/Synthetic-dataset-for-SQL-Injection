public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE users SET isDependent=? WHERE MID=?");
		stmt.setObject(1 , mid);
		stmt.executeUpdate();
	}
}