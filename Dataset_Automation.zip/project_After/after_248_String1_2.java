public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM course WHERE idcourse != ? ORDER BY courname;");
		stmt.setObject(1 , oldCourseId);
		stmt.executeQuery();
	}
}