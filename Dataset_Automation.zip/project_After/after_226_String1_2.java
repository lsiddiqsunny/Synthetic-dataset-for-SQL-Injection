public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM npc WHERE npc_name = ?");
		stmt.setObject(1 , name);
		stmt.executeQuery();
	}
}