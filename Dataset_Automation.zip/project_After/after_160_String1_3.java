public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "update inception_music set CTR = CTR + 1 where id = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.executeUpdate();
	}
}