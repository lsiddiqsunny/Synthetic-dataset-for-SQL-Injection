public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("insert into book values (?, '?', ?)");
		stmt.setObject(1 , id);
		stmt.setObject(2 , book.getName());
		stmt.setObject(3 , book.getIdAuthor());
		stmt.executeUpdate();
	}
}