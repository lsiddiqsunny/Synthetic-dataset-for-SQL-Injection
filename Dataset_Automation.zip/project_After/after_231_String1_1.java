public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO OptionVisite (id, label, niveau, parent, type, typeB) VALUES (?, ?, ?, ?, ?, ?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getId());
		stmt.setObject(2 , obj.getLabel());
		stmt.setObject(3 , obj.getNiveau());
		stmt.setObject(4 , obj.getParent());
		stmt.setObject(5 , obj.getType());
		stmt.setObject(6 , obj.getTypeB());
		stmt.executeUpdate();
	}
}