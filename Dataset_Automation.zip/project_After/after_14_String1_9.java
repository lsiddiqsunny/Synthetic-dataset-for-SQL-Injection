public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("delete from Resurse_Financiare where id=?");
		stmt.setObject(1 , id);
		stmt.executeUpdate();
	}
}