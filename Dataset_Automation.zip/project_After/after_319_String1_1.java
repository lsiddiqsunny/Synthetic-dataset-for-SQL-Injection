public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE tbl_peliculas SET nombre = ?, genero = ?, clasificacion = ?, duracion = ?, imagen = ? WHERE pk_pelicula = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , entidad.getNombre());
		stmt.setObject(2 , entidad.getGenero());
		stmt.setObject(3 , entidad.getClasificacion());
		stmt.setObject(4 , entidad.getDuracion());
		stmt.setObject(5 , entidad.getImagen());
		stmt.setObject(6 , entidad.getIdPelicula());
		stmt.executeUpdate();
	}
}