public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * " + "FROM (SELECT id, pwd, name, phone, email, address, memo, rating, rownum as num FROM member) " + "WHERE num >= ? AND num <= ?");
		stmt.setObject(1 , start);
		stmt.setObject(2 , end);
		stmt.executeQuery();
	}
}