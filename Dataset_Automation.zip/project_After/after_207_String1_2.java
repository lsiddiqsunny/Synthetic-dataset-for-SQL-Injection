public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO user(name,pass) VALUES(?,?)");
		stmt.setObject(1 , name);
		stmt.setObject(2 , pass);
		stmt.executeUpdate();
	}
}