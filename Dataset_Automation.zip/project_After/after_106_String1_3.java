public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "DELETE FROM member WHERE id=?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , strId);
		stmt.executeUpdate();
	}
}