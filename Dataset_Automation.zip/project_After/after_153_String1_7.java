public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "select * from movie_feature where movie_id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , movie_id);
		stmt.executeQuery();
	}
}