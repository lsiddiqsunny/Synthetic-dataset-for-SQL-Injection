public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT role FROM users WHERE MID=? AND Role=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , mid);
		stmt.setObject(2 , role);
		stmt.executeQuery();
	}
}