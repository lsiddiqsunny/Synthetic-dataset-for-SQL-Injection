public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM user WHERE Login = '?' AND Password=" + "'?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , uname);
		stmt.setObject(2 , pwd);
		stmt.executeQuery();
	}
}