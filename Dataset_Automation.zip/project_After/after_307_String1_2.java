public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO Pays (codePays, nomPays) VALUES (?, ?)");
		stmt.setObject(1 , obj.getCodePays());
		stmt.setObject(2 , obj.getNomPays());
		stmt.executeUpdate();
	}
}