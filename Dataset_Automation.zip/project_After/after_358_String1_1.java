public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE loginfailures SET failureCount=0 WHERE IPAddress=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , ipAddr);
		stmt.executeUpdate();
	}
}