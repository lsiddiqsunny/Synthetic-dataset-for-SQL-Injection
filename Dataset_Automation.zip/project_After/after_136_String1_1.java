public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM ModRgl WHERE codeModRgl = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , code);
		stmt.executeQuery();
	}
}