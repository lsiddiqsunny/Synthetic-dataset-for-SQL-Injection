public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT SUM(quantite) AS nb FROM ParcClient WHERE codeTParc = ?" + " AND codeCliPros IN" + "  (SELECT cClient FROM Client WHERE cRep = ?" + "  OR cClient IN" + "    (SELECT codeCliPros FROM Revoir WHERE codeUtilisateur = ?)" + "  )";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , codeParc);
		stmt.setObject(2 , PanelStats.commercialStats.getCodeCommercial());
		stmt.setObject(3 , PanelStats.commercialStats.getId());
		stmt.executeQuery();
	}
}