public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT docfile FROM document WHERE iddocument = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , selFile.getDocid());
		stmt.executeQuery();
	}
}