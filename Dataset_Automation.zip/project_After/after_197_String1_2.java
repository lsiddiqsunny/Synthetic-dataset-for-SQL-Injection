public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM cluster_table where name='?'");
		stmt.setObject(1 , name);
		stmt.executeUpdate();
	}
}