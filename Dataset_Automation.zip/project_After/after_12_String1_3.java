public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		String sql = "Insert into User(id,firstName,lastName,userName,email,password,mobileNo) values(?,?,?,?,?,?,?)";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , userInfo.getId());
		stmt.setObject(2 , userInfo.getFirstName());
		stmt.setObject(3 , userInfo.getLastName());
		stmt.setObject(4 , userInfo.getUserName());
		stmt.setObject(5 , userInfo.getEmail());
		stmt.setObject(6 , userInfo.getPassword());
		stmt.setObject(7 , userInfo.getMobileNo());
		stmt.executeUpdate();
	}
}