public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT COUNT(*) AS activityLineInstances1 FROM ActivityLine " + "WHERE activityId= '?' " + "AND bookingId= '?' " + "AND date= '?' " + "AND startHour= '?' " + "AND facilityId= '?' " + "AND status= '?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , activityId);
		stmt.setObject(2 , bookingId);
		stmt.setObject(3 , date);
		stmt.setObject(4 , startHour);
		stmt.setObject(5 , facilityId);
		stmt.setObject(6 , status);
		stmt.executeQuery();
	}
}