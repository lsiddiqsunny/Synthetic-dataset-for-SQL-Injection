public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE ActivityBooking SET " + " status= '?' " + "WHERE id= '?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , activityBookingObj.getStatus());
		stmt.setObject(2 , activityBookingObj.getId());
		stmt.executeUpdate();
	}
}