public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("delete from ? where ?=?");
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_ID);
		stmt.setObject(3 , id_nodo);
		stmt.executeUpdate();
	}
}