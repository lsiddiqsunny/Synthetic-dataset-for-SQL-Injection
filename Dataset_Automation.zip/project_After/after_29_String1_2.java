public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE tblAchievements SET fldStatus=? WHERE id=?;");
		stmt.setObject(1 , editAchievementStatus);
		stmt.setObject(2 , editIDResult);
		stmt.executeUpdate();
	}
}