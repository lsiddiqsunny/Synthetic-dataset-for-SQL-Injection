public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("select * from ? where ? = ?");
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_QUOTA);
		stmt.setObject(3 , quota);
		stmt.executeQuery();
	}
}