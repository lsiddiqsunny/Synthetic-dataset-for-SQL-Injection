public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE users SET password=?, salt=? WHERE MID=?");
		stmt.setObject(1 , newPassword);
		stmt.setObject(2 , salt);
		stmt.setObject(3 , mid);
		stmt.executeUpdate();
	}
}