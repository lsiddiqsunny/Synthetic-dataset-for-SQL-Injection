public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		stmt = conn.prepareStatement("UPDATE message SET been_read=1 WHERE message_id=?");
		stmt.setObject(1 , mBean.getMessageId());
		stmt.executeUpdate();
	}
}