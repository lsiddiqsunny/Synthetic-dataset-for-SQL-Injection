public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE ndcodes SET Description = ? " + "WHERE Code = ?");
		stmt.setObject(1 , med.getDescription());
		stmt.setObject(2 , med.getNDCode());
		stmt.executeUpdate();
	}
}