public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE users SET sQuestion = ?, sAnswer = ? WHERE MID = ?");
		stmt.setObject(1 , question);
		stmt.setObject(2 , answer);
		stmt.setObject(3 , mid);
		stmt.executeUpdate();
	}
}