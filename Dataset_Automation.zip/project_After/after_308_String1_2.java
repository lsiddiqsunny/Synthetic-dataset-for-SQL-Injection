public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("DELETE FROM Pays WHERE id = ?");
		stmt.setObject(1 , obj.getId());
		stmt.executeUpdate();
	}
}