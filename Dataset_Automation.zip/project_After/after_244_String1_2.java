public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE ActivityBooking SET " + " status= '?' " + "WHERE id= '?'");
		stmt.setObject(1 , activityBookingObj.getStatus());
		stmt.setObject(2 , activityBookingObj.getId());
		stmt.executeUpdate();
	}
}