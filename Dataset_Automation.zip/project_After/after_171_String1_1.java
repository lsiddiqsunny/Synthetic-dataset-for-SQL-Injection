public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "update userinfo set pw=?, email=? where id=? and pw=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , cpw);
		stmt.setObject(2 , email);
		stmt.setObject(3 , id);
		stmt.setObject(4 , pw);
		stmt.executeUpdate();
	}
}