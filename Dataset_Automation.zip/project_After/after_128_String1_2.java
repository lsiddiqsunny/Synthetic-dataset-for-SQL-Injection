public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM message WHERE original_msg_id=?");
		stmt.setObject(1 , refID);
		stmt.executeQuery();
	}
}