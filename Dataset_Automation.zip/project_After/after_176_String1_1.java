public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "delete FROM book where id = ? and name= '?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , book.getId());
		stmt.setObject(2 , book.getName());
		stmt.executeUpdate();
	}
}