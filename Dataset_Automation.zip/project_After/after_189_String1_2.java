public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("INSERT INTO virtual_machine_host_table VALUES(" + "'?'," + "'?'," + "'?')");
		stmt.setObject(1 , host.getHostName());
		stmt.setObject(2 , host.getIp());
		stmt.setObject(3 , host.getNaeglingPort());
		stmt.executeUpdate();
	}
}