public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT * FROM tbl_peliculas WHERE pk_pelicula = ?");
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}