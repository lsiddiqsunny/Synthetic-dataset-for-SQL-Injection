public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "update adv_pendencia.tab_pasta set statusPasta = 'ocupado' where idPasta = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , filtro.getPasta());
		stmt.executeUpdate();
	}
}