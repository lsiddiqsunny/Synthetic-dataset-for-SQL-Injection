public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = null;
		sql = "SELECT * FROM ModRgl WHERE codeModRgl = ?";
		stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , code);
		stmt.executeQuery();
	}
}