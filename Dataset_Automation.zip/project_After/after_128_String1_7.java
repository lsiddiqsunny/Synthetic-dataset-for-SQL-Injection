public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		sql = "SELECT * FROM message WHERE original_msg_id=?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , refID);
		stmt.executeQuery();
	}
}