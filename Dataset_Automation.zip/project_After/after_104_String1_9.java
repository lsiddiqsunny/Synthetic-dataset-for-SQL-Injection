public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt;
		stmt = conn.prepareStatement("UPDATE member SET memo=?, rating=? WHERE id=?");
		stmt.setObject(1 , memo);
		stmt.setObject(2 , rating);
		stmt.setObject(3 , id);
		stmt.executeUpdate();
	}
}