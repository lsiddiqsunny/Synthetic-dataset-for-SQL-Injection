public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "SELECT * FROM tbl_peliculas WHERE pk_pelicula = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , id);
		stmt.executeQuery();
	}
}