public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("SELECT patients.* FROM representatives, patients " + "WHERE RepresenteeMID=? AND RepresenterMID=patients.MID");
		stmt.setObject(1 , pid);
		stmt.executeQuery();
	}
}