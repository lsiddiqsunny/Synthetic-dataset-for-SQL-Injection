public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "INSERT INTO declaredhcp(PatientID, HCPID) VALUES(?,?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , pid);
		stmt.setObject(2 , hcpID);
		stmt.executeUpdate();
	}
}