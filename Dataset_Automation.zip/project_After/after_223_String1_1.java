public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "insert into ?(?) values(?)";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , TBL_NAME);
		stmt.setObject(2 , FIELD_EMERG);
		stmt.executeUpdate();
	}
}