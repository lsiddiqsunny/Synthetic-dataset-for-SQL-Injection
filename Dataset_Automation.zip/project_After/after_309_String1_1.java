public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "UPDATE Pays SET codePays = ?, nomPays = ? WHERE id = ?";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , obj.getCodePays());
		stmt.setObject(2 , obj.getNomPays());
		stmt.setObject(3 , obj.getId());
		stmt.executeUpdate();
	}
}