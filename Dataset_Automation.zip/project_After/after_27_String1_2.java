public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		PreparedStatement stmt = conn.prepareStatement("UPDATE tblAchievements SET fldProgress=? WHERE id=?;");
		stmt.setObject(1 , newProgressResult);
		stmt.setObject(2 , ID);
		stmt.executeUpdate();
	}
}