public class Dummy {
void sendRequest(Connection conn) throws SQLException {
		String sql = "DELETE FROM ActivityLine WHERE activityId= '?' AND bookingId= '?' AND date= '?' AND startHour= '?'";
		PreparedStatement stmt = conn.prepareStatement(sql);
		stmt.setObject(1 , activityId);
		stmt.setObject(2 , bookingId);
		stmt.setObject(3 , date);
		stmt.setObject(4 , startHour);
		stmt.executeUpdate();
	}
}